"""API reference documentation for FLIM package."""

__all__ = ["__version__"]

from ._version import __version__
