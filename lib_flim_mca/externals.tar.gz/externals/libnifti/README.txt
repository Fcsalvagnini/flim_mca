Created by Samuka Martins on 06/20/2017
Based on nifticlib-2.0.0, available on https://sourceforge.net/projects/niftilib/files/nifticlib/

